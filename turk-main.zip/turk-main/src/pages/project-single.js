
import SinglieProject from '@/components/pages/project/singlie-project'
export default function Products() {
  return (
    <>
      <SinglieProject/>
    </>
  )
}
