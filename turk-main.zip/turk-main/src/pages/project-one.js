import ProductPage from '@/components/pages/project'
import ProductOnePage from "@/components/pages/project/one-project"
export default function Products() {
  return (
    <>
      <ProductOnePage/>
    </>
  )
}
