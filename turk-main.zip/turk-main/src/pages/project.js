import ProductPage from '@/components/pages/project'
import React from 'react'

export default function Products() {
  return (
    <>
      <ProductPage/>
    </>
  )
}
